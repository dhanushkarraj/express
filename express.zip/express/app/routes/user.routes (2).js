module.exports = (app) => {
    var router = require("express").Router();
  
    const allUserController = require("../controller/user.controller");
  
    router.post("/allUsers", allUserController.newUser);
router.get("/getUser",allUserController.fetchAllUsers)
router.put("/:id",allUserController.updateAllUsers)
router.delete("/:id",allUserController.deleteAllUsers)


    app.use("/user", router);
  };
  