module.exports = (mongoose) => {
    const User = mongoose.model(
      "userdetails",
      mongoose.Schema(
        {
            email:{type:String},
            name:{type:String}, 
        },
        { timestamps: true },
      ),
    );
    return User;
  };
  