const db = require("../models");
const User = db.user;
const allUserService = require("../service/allUser.service");
module.exports = {
  fetchUserDetailservice: async (userId) => {
    try {
      const userDetails = await User.findOne(userId);
      return userDetails;
    } catch (error) {
      console.error("Error fetching user details:", error);
      return error.message;
    }
  }
}