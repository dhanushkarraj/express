const db = require("../models");
const User = db.user;
require("dotenv").config();
exports.newUser = async (req, res, next) => {
  try {
    const user = new User({
      name: req.body.name,
      email: req.body.email,
    });
    user
      .save(user)
      .then((data) => {
        res.send(data);
      })
      .catch((err) => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the users.",
        });
      });
  } catch (err) {
    res.status(500).send({
      message: err.message || "Some error occurred while creating the users.",
    });
  }
  
};
exports.fetchAllUsers = async (req, res) => {
  try {
    const users = await User.find()
    res.status(200).json({
      status: 1,
      message: "Successfully fetched User Profile Details",
      allUser: users,
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
exports.updateAllUsers = async (req, res) => {
  try {
    const id = req.params.id
    const users = await User.findByIdAndUpdate(id,req.body)
    res.status(200).json({
      status: 1,
      message: "Successfully fetched User Profile Details",
      allUser: users,
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
exports.deleteAllUsers = async (req, res) => {
  try {
    const id = req.params.id
    const users = await User.deleteOne({_id:id})
    res.status(200).json({
      status: 1,
      message: "Successfully fetched User Profile Details",
      allUser: users,
    });
  } catch (error) {
    res.status(400).json({
      status: 0,
      message: error.message,
    });
  }
};
